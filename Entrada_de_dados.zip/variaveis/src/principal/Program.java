package principal;

public class Program {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int x = 10;
		double preco = 43.99;
		String nome = "Alfa";
		char sexo = 'M';
		/*System.out.println(preco);
		System.out.println(nome);
		
		System.out.println(nome + " " + "camisa" + " " + preco);
		
		nome = "Bravo";
		
		System.out.println(nome + " " + "camisa" + " " + preco);
		*/
		System.out.println();
		
		int a = x + 5;
		System.out.println(a);
		System.out.println(" x");
		System.out.println(a+600);
		System.out.println("Resultado ; " + (a + x));
		
		String idade = String.format( "qual � a idade?");
		
		JOptionPane.showMessageDialog ( null, idade );
	}

}
